#include <windows.h>
extern HANDLE inLicEvent, outLicEvent;
void licpatch(void)
{
/*
	static int first = 0;
	if (!first)
	{
		first++;
		outLicEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
		SetEvent(inLicEvent);
		WaitForSingleObject(outLicEvent, INFINITE);
	}
	*/
}