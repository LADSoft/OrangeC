#if 0
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "PEHeader.h"
#include "sha1.h"
typedef struct {
    char String[4 * 4];
} IP_ADDRESS_STRING, *PIP_ADDRESS_STRING, IP_MASK_STRING, *PIP_MASK_STRING;
typedef struct _IP_ADDR_STRING {
    struct _IP_ADDR_STRING* Next;
    IP_ADDRESS_STRING IpAddress;
    IP_MASK_STRING IpMask;
    DWORD Context;
} IP_ADDR_STRING, *PIP_ADDR_STRING;
#define MAX_ADAPTER_DESCRIPTION_LENGTH  128 // arb.
#define MAX_ADAPTER_NAME_LENGTH         256 // arb.
#define MAX_ADAPTER_ADDRESS_LENGTH      8   // arb.
typedef struct _IP_ADAPTER_INFO {
    struct _IP_ADAPTER_INFO* Next;
    DWORD ComboIndex;
    char AdapterName[MAX_ADAPTER_NAME_LENGTH + 4];
    char Description[MAX_ADAPTER_DESCRIPTION_LENGTH + 4];
    UINT AddressLength;
    BYTE Address[MAX_ADAPTER_ADDRESS_LENGTH];
    DWORD Index;
    UINT Type;
    UINT DhcpEnabled;
    PIP_ADDR_STRING CurrentIpAddress;
    IP_ADDR_STRING IpAddressList;
    IP_ADDR_STRING GatewayList;
    IP_ADDR_STRING DhcpServer;
    BOOL HaveWins;
    IP_ADDR_STRING PrimaryWinsServer;
    IP_ADDR_STRING SecondaryWinsServer;
    time_t LeaseObtained;
    time_t LeaseExpires;
} IP_ADAPTER_INFO, *PIP_ADAPTER_INFO;
typedef DWORD __stdcall Func(IP_ADAPTER_INFO *, DWORD *);
typedef HMODULE __stdcall LoadLibraryType(char *name);
typedef void * __stdcall GetProcAddressType(HMODULE ll, char *name);
typedef HANDLE __stdcall CEFunc(void *sa, BOOL manreset, BOOL state, void *na);
typedef HANDLE __stdcall WEFunc(HANDLE h, DWORD to);
typedef HANDLE __stdcall SEFunc(HANDLE h);
typedef HANDLE __stdcall CTFunc(void *sa, DWORD stack, LPTHREAD_START_ROUTINE start, LPVOID param,DWORD flags, LPDWORD threadId);
/*
static LoadLibraryType *LoadLibraryFunc = NULL;
static GetProcAddressType *GetProcAddressFunc = NULL;
*/
static int code = 22334455;
static int ok = 0;
static unsigned char hash[20] = { 0 };
static HANDLE starter = NULL;
#define AA(x) ((x) ^ 0xe3)
static const char iphlpapi[] = { AA('I'),AA('P'),AA('H'),AA('L'),AA('P'),AA('A'),AA('P'),AA('I'),AA('.'),AA('D'),AA('L'),AA('L'), AA(0) };
static const char getAdaptersInfo[] = { AA('G'),AA('e'),AA('t'),AA('A'),AA('d'),AA('a'),AA('p'),AA('t'),AA('e'),AA('r'),AA('s'),AA('I'),AA('n'),AA('f'),AA('o'),AA(0) };
static const char envOrangec[] = { AA('O'),AA('R'),AA('A'),AA('N'),AA('G'),AA('E'),AA('C'), AA(0) };
static const char licFile[] = { AA('b'),AA('i'),AA('n'),AA('\\'),AA('o'),AA('r'),AA('a'),AA('n'),AA('g'),AA('e'),AA('c'),AA('.'),AA('l'),AA('i'),AA('c'), AA(0) };
static const char licenseData[] = { AA('L'),AA('i'),AA('c'),AA('e'),AA('n'),AA('s'),AA('e'),AA(' '),AA('d'),AA('a'),AA('t'),AA('a'),AA(':'), AA(0) };
static const char format[] = { AA('%'),AA('0'),AA('2'),AA('X'),AA(' '), AA(0) };
static const char kernel32[] = { AA('K'),AA('E'),AA('R'),AA('N'),AA('E'),AA('L'),AA('3'),AA('2'),AA('.'),AA('D'),AA('L'),AA('L'),AA(0) };
static const char exitProcess[] = { AA('E'),AA('x'),AA('i'),AA('t'),AA('P'),AA('r'),AA('o'),AA('c'),AA('e'),AA('s'),AA('s'),AA(0) };
static const char loadLibrary[] = { AA('L'),AA('o'),AA('a'),AA('d'),AA('L'),AA('i'),AA('b'),AA('r'),AA('a'),AA('r'),AA('y'),AA('A'),AA(0) };
static const char getProcAddress[] = { AA('G'),AA('e'),AA('t'),AA('P'),AA('r'),AA('o'),AA('c'),AA('A'),AA('d'),AA('d'),AA('r'),AA('e'),AA('s'),AA('s'),AA(0) };
static const char createFile[] = { AA('C'),AA('r'),AA('e'),AA('a'),AA('t'),AA('e'),AA('F'),AA('i'),AA('l'),AA('e'),AA('A'),AA(0) };
static const char readFile[] = { AA('R'),AA('e'),AA('a'),AA('d'),AA('F'),AA('i'),AA('l'),AA('e'),AA(0) };
static const char closeHandle[] = { AA('C'),AA('l'),AA('o'),AA('s'),AA('e'),AA('H'),AA('a'),AA('n'),AA('d'),AA('l'),AA('e'),AA(0) };
static const char createEvent[] = { AA('C'),AA('r'),AA('e'),AA('a'),AA('t'),AA('e'),AA('E'),AA('v'),AA('e'),AA('n'),AA('t'),AA('A'),AA(0) } ;
static const char waitForSingleObject[] = { AA('W'),AA('a'),AA('i'),AA('t'),AA('F'),AA('o'),AA('r'),AA('S'),AA('i'),AA('n'),AA('g'),AA('l'),AA('e'),AA('O'),AA('b'),AA('j'),AA('e'),AA('c'),AA('t'),AA(0) } ;
static const char setEvent[] = { AA('S'),AA('e'),AA('t'),AA('E'),AA('v'),AA('e'),AA('n'),AA('t'),AA(0) } ;
static const char createThread[] = { AA('C'),AA('r'),AA('e'),AA('a'),AA('t'),AA('e'),AA('T'),AA('h'),AA('r'),AA('e'),AA('a'),AA('d'),AA(0) } ;
// these are the only BSS variables this module
HANDLE inLicEvent, outLicEvent;
static int aa[64];
static int accessor[1];

static void get(char *buf, const char *data)
{
	do
	{
		*buf++ = AA(*data++);
	} while (buf[-1] != 0);
}
/*
static int FindImportAddress(int imageBase, const char *name)
{
	struct PEHeader *p = (struct PEHeader *)((*(unsigned *)(imageBase + 0x3c)) + imageBase);
	char buf[256];
	char kern[256];
	struct PEImport *pi;

    accessor[0] = p->import_rva;
    if (accessor[0] == 0)
        return 0;
	get(buf, name);
	get(kern, kernel32);
    do
    {
		pi = (struct PEImport *)(imageBase + accessor[0]);
        if (pi->dllName)
        {
            if (!stricmp((char *)imageBase + pi->dllName, kern))
            {
                int namepos = pi->thunkPos2 + imageBase;
                int addrpos = pi->thunkPos + imageBase;
                do
                {
                    int nametext;
					if (!*(unsigned *)namepos)
						return 0;
                    nametext = *(int*)namepos + imageBase;
                    if (!strcmp((char *)nametext + 2, buf))
                    {
						memset(buf, 0, sizeof(buf));
						memset(kern, 0, sizeof(kern));
                        return *(int*)addrpos;
                    } 
					namepos += 4;
                    addrpos += 4;
                }
                while (TRUE);

            }
            accessor[0] += sizeof(struct PEImport);
        }

    }
    while (pi->dllName)
        ;
	memset(buf, 0, sizeof(buf));
	memset(kern, 0, sizeof(kern));

    return 0;
}
*/
static void *GetFunc(const char *dll, const char *func)
{
	void *rv = NULL;
	char buf1[256],buf2[256];
	HMODULE h;
	get(buf1, dll);
	get(buf2, func);
	h = LoadLibrary(buf1);
	if (h)
	{
		rv = GetProcAddress(h, buf2);
	}
	memset(buf1, 0, sizeof(buf1));
	memset(buf2, 0, sizeof(buf2));
	return rv;
}
static int GetMac(unsigned char mac[6])
{
  char buf1[256], buf2[256];
  Func *func = (Func *)GetFunc(iphlpapi, getAdaptersInfo);
  accessor[0] = 0;
  if (func)
  {
	  IP_ADAPTER_INFO *pAdapterInfo;
	  DWORD dwStatus = func(NULL, (DWORD *)&accessor[0]);
	  if (dwStatus != ERROR_BUFFER_OVERFLOW)
		  return 0;
	  pAdapterInfo = (IP_ADAPTER_INFO *)calloc(accessor[0], 1);
	  if (!pAdapterInfo)
		  return 0;
	  dwStatus = func(pAdapterInfo, (DWORD *)&accessor[0]);
	  if (dwStatus != ERROR_SUCCESS)
	  {
	  	  free(pAdapterInfo);
		  return 0;
	  }
	  memcpy(mac, pAdapterInfo[0].Address, 6);
	  free(pAdapterInfo);
	  return 1;
  }
  return 0;
}
void Quit(void)
{
	typedef void __stdcall Exit(DWORD v);
	Exit *p = (Exit *)GetFunc(kernel32, exitProcess);
	if (p)
		p(0);
	else
		while (1);
}
typedef HANDLE __stdcall CFFunc(
    LPCTSTR  lpFileName,	// address of name of the file 
    DWORD  dwDesiredAccess,	// access (read-write) mode 
    DWORD  dwShareMode,	// share mode 
    LPSECURITY_ATTRIBUTES  lpSecurityAttributes,	// address of security descriptor 
    DWORD  dwCreationDistribution,	// how to create 
    DWORD  dwFlagsAndAttributes,	// file attributes 
    HANDLE  hTemplateFile 	// handle of file with attributes to copy  
   );	
typedef DWORD __stdcall RDFunc(HANDLE h, void *buf, DWORD len, DWORD *readlen, void *nl);
typedef DWORD __stdcall CLFunc(HANDLE h);
static void read(char *buf)
{
	CFFunc *cf = (CFFunc *)GetFunc(kernel32, createFile);
	RDFunc *rd = (RDFunc *)GetFunc(kernel32, readFile);
	CLFunc *cl = (CLFunc *)GetFunc(kernel32, closeHandle);
	if (cf && rd && cl)
	{
		HANDLE h = cf(buf, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
		memset(buf, 0, 256);
		if (h != INVALID_HANDLE_VALUE)
		{
			DWORD readLen;
			rd(h,buf,20,&readLen, NULL);
			cl(h);	
		}
	}
	else
	{
		memset(buf,0,256);
	}
}
DWORD __stdcall doLic(void *aa)
{
	CEFunc *ce = (CEFunc *)GetFunc(kernel32, createEvent);
	WEFunc *we = (WEFunc *)GetFunc(kernel32, waitForSingleObject);
	SEFunc *se = (SEFunc *)GetFunc(kernel32, setEvent);
	if (!ce || !we || !se)
		Quit();
	accessor[-66] = (int)ce(NULL, TRUE, FALSE, NULL);
	se(starter);
	we((HANDLE)accessor[-66], INFINITE);
	if (!ok)
	{
		int i;
		char buf1[256], buf2[256];
		get(buf1, licenseData);
		get(buf2, format);
		puts(buf1);
		for (i=0; i < 20; i++)
			printf(buf2, ((unsigned char *)hash)[i]);
		memset(hash, 0, sizeof(hash));
		Quit();
	}		
	memset(hash, 0, sizeof(hash));
	se((HANDLE)accessor[-65]);
}
void test(void)
{
	CEFunc *ce;
	WEFunc *we;
	CTFunc *ct;
	DWORD id;
	unsigned char mac[6];
	/*
	LoadLibraryFunc = (LoadLibraryType *)FindImportAddress(0x400000, loadLibrary);
	GetProcAddressFunc = (GetProcAddressType *)FindImportAddress(0x400000, getProcAddress);
	*/
	ce = (CEFunc *)GetFunc(kernel32, createEvent);
	we = (WEFunc *)GetFunc(kernel32, waitForSingleObject);
	ct = (CTFunc *)GetFunc(kernel32, createThread);
	if (!ce || !we || !ct)
	{
		Quit();
	}
	starter = ce(NULL, TRUE, FALSE, NULL);
	ct(NULL, 0, (LPTHREAD_START_ROUTINE)doLic, 0, 0, &id);
	
	we(starter, INFINITE);
	if (GetMac(mac))
	{
		FILE *fil;
		char buf[256],*p;
		char envname[256];
		int len;
		SHA1Context one;
		SHA1Context two;
		SHA1Context three;
		get(envname, envOrangec);
		p = getenv(envname);
		if (!p)
			return;
		strcpy(buf, p);
		len = strlen(buf);
		if (buf[len-1] != '\\')
			strcat(buf, "\\");
		get(buf + strlen(buf), licFile);
		read(buf);		
		SHA1Reset(&one);
		SHA1Reset(&two);
		SHA1Reset(&three);
		SHA1Input(&one, (unsigned char *)&code, 4);
		if (!SHA1Result(&one))
			return;
		SHA1Input(&two, mac, 6);
		SHA1Input(&two, (unsigned char *)&code, 4);
		if (!SHA1Result(&two))
			return;
		SHA1Input(&three, (unsigned char *)one.Message_Digest, 20);
		SHA1Input(&three, (unsigned char *)two.Message_Digest, 20);
		if (!SHA1Result(&three))
			return;
		memcpy(hash, two.Message_Digest, 20);
		ok = !memcmp(three.Message_Digest, buf, 20);
	}
}
static void dummy(void)
{
	typedef void __stdcall Exit(DWORD);
	HMODULE ll = LoadLibrary("KERNEL32.DLL");
	Exit *func = (Exit *)GetProcAddress(ll, "ExitProcess");
	(*func)(1);
}
/*
int main()
{
	outLicEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	SetEvent(inLicEvent);
	WaitForSingleObject(outLicEvent, INFINITE);
	printf("ok.");
	return 0;
}
*/
#pragma startup test 100

#endif