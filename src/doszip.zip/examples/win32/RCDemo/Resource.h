#ifdef RC_INVOKED
#define __NEXT_CONTROL_ID	4
#define __NEXT_MENU_ID		10000
#define __NEXT_RESOURCE_ID	11
#define __NEXT_STRING_ID	1000
#endif
#define IDD_TEST 10
#define IDC_VEGGI 102
#define IDC_FRUIT 100
