#include <windows.h>

#ifndef _WIN32
#define _WIN32
#endif

#ifndef IDC_STATIC
#define IDC_STATIC -1
#endif
