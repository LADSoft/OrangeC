#include <windows.h>
#include <iphlpapi.h>
#include <stdlib.h>
#include <stdio.h>
#include "sha1.h"
int code = 22334455;
int write(unsigned char data[20])
{
	FILE *fil;
	char buf[256],*p;
	int len;
	SHA1Context one;
	SHA1Context three;
	strcpy(buf, "orangec.lic");
	SHA1Reset(&one);
	SHA1Reset(&three);
	SHA1Input(&one, &code, 4);
	if (!SHA1Result(&one))
		return 0;
	SHA1Input(&three, one.Message_Digest, 20);
	SHA1Input(&three, data, 20);
	if (!SHA1Result(&three))
		return 0;
	fil = fopen(buf, "wb");
	if (!fil)
		return 0;
	if (fwrite(three.Message_Digest, 1, 20, fil) != 20)
	{
		fclose(fil);
		return 0;
	}
	fclose(fil);
	return 1;
}
int main(int argc, char **argv)
{
	unsigned char data[20];
	int i;
	if (argc != 21)
	{
		printf("Error");
		exit(1);
	}
	for (i=1; i < 21; i++)
	{
		data[i-1] = strtoul(argv[i], NULL, 16);
	}
	write(data);
}