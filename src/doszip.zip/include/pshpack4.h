#if ! (defined(lint) || defined(_lint) || defined(RC_INVOKED))
#pragma pack(4)
#endif