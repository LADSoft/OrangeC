#define CCF_NOTEXT (1)
#define CCHCCCLASS (32)
#define CCHCCDESC (32)
#define CCHCCTEXT (256)

