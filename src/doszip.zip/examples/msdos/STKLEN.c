int _stklen = 100 * 1024 ;

int main(int argc, char **argv)
{
   printf("stack size is 100K") ;
}