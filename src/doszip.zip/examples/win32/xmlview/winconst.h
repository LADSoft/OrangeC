#define IDM_ABOUT 100
#define IDM_EXIT 101
#define IDM_OPEN 102